Medical Chatbot
Welcome to the Medical Chatbot project. This chatbot is designed to provide medical information and answer queries related to common medical conditions. It uses the Llama 2 model, specifically the quantized llama-2-7b-chat.ggmlv3.q8_0 version, to understand user questions and provide accurate, reliable information.
